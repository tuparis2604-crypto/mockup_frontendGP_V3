/**
 * API Service Layer
 * Modo MOCK com localStorage para desenvolvimento
 * Pronto para integrar com n8n (basta trocar API_BASE_URL)
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || ""; // Vazio = modo MOCK

// ============================================================================
// TIPOS E INTERFACES
// ============================================================================

// Hierarquia de roles (maior para menor)
const ROLE_HIERARCHY: Record<string, number> = {
  "Sócio": 4,
  "RH": 3,
  "Gestor": 2,
  "Colaborador": 1,
};

export function getHighestRole(roles: string[]): string {
  return roles.reduce((highest, current) => {
    const currentRank = ROLE_HIERARCHY[current] || 0;
    const highestRank = ROLE_HIERARCHY[highest] || 0;
    return currentRank > highestRank ? current : highest;
  }, "Colaborador");
}

export interface User {
  id: string;
  name: string;
  email: string;
  roles: ("Colaborador" | "Gestor" | "RH" | "Sócio")[];
  faixa: "Ciclo I" | "Ciclo II" | "Ciclo III";
  manager_id?: string;
  primary_macros: string[];
  created_at: string;
}

export interface Attachment {
  name: string;
  url: string;
  type: string;
}

export interface Checkin {
  id: string;
  created_at: string;
  subject_user_id: string;
  author_user_id: string;
  type: "positive" | "improvement";
  macro: string;
  text: string;
  visibility: "private" | "visible";
  attachments: Attachment[];
  evaluation?: {
    status: "valid" | "invalid" | null;
    evaluated_by?: string;
    evaluated_at?: string;
    points_modifier?: number; // +10 para válido, -5 para inválido
  };
}

export interface CheckinEvaluation {
  checkin_id: string;
  status: "valid" | "invalid";
  evaluated_by: string;
  points_modifier: number;
}

export interface Summary {
  id: string;
  user_id: string;
  period_from: string;
  period_to: string;
  audience: "self" | "manager" | "hr" | "public";
  content: string;
  created_at: string;
}

export interface OtpResponse {
  success: boolean;
  message: string;
  token?: string;
}

// ============================================================================
// DADOS SEED (MOCK)
// ============================================================================

const SEED_USERS: User[] = [
  {
    id: "user-1",
    name: "João",
    email: "joao@company.com",
    roles: ["RH"],
    faixa: "Ciclo III",
    primary_macros: ["Gestão de Pessoas", "Comunicação"],
    created_at: "2025-01-15T10:00:00Z",
  },
  {
    id: "user-2",
    name: "Maria",
    email: "maria@company.com",
    roles: ["Sócio"],
    faixa: "Ciclo III",
    primary_macros: ["Visão Estratégica", "Liderança"],
    created_at: "2025-01-10T10:00:00Z",
  },
  {
    id: "user-3",
    name: "Carlos",
    email: "carlos@company.com",
    roles: ["Gestor"],
    faixa: "Ciclo II",
    manager_id: "user-2",
    primary_macros: ["Liderança", "Comunicação"],
    created_at: "2025-01-05T10:00:00Z",
  },
  {
    id: "user-4",
    name: "Ana",
    email: "ana@company.com",
    roles: ["Colaborador"],
    faixa: "Ciclo II",
    manager_id: "user-3",
    primary_macros: ["Comunicação", "Trabalho em Equipe"],
    created_at: "2024-12-01T10:00:00Z",
  },
];

const SEED_MACROS = [
  "Liderança",
  "Comunicação",
  "Resolução de Problemas",
  "Trabalho em Equipe",
  "Inovação",
  "Gestão de Pessoas",
  "Visão Estratégica",
  "Foco em Resultados",
];

const SEED_CHECKINS: Checkin[] = [
  {
    id: "checkin-1",
    created_at: "2026-02-20T14:30:00Z",
    subject_user_id: "user-1",
    author_user_id: "user-1",
    type: "positive",
    macro: "Liderança",
    text: "Liderou com sucesso a reunião de planejamento trimestral, alinhando toda a equipe com os objetivos.",
    visibility: "visible",
    attachments: [],
  },
  {
    id: "checkin-2",
    created_at: "2026-02-19T10:15:00Z",
    subject_user_id: "user-1",
    author_user_id: "user-1",
    type: "improvement",
    macro: "Comunicação",
    text: "Preciso melhorar na comunicação de feedbacks difíceis. Vou buscar treinamento.",
    visibility: "private",
    attachments: [],
  },
  {
    id: "checkin-3",
    created_at: "2026-02-18T16:45:00Z",
    subject_user_id: "user-1",
    author_user_id: "user-3",
    type: "positive",
    macro: "Resolução de Problemas",
    text: "Resolveu rapidamente o problema crítico do cliente com pensamento estratégico.",
    visibility: "visible",
    attachments: [],
  },
  {
    id: "checkin-4",
    created_at: "2026-02-17T09:00:00Z",
    subject_user_id: "user-1",
    author_user_id: "user-1",
    type: "positive",
    macro: "Inovação",
    text: "Propôs solução inovadora para otimizar o processo de vendas.",
    visibility: "visible",
    attachments: [],
  },
  {
    id: "checkin-5",
    created_at: "2026-02-15T13:20:00Z",
    subject_user_id: "user-1",
    author_user_id: "user-1",
    type: "positive",
    macro: "Trabalho em Equipe",
    text: "Colaborou efetivamente com o time de produto na entrega do projeto.",
    visibility: "visible",
    attachments: [],
  },
];

// ============================================================================
// STORAGE HELPERS
// ============================================================================

const getStorage = (key: string, defaultValue: any = null) => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
};

const setStorage = (key: string, value: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Failed to save ${key} to localStorage:`, error);
  }
};

const initializeStorage = () => {
  if (!getStorage("users")) {
    setStorage("users", SEED_USERS);
  }
  if (!getStorage("macros")) {
    setStorage("macros", SEED_MACROS);
  }
  if (!getStorage("checkins")) {
    setStorage("checkins", SEED_CHECKINS);
  }
};

// ============================================================================
// AUTH ENDPOINTS
// ============================================================================

export async function requestOtp(email: string): Promise<OtpResponse> {
  if (API_BASE_URL) {
    return fetch(`${API_BASE_URL}/auth/request-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    }).then((r) => r.json());
  }

  // MOCK MODE
  const users = getStorage("users", SEED_USERS);
  const userExists = users.some((u: User) => u.email === email);

  if (!userExists) {
    return { success: false, message: "Email não encontrado" };
  }

  // Store OTP attempt
  setStorage(`otp_${email}`, {
    code: "123456",
    attempts: 0,
    created_at: new Date().toISOString(),
  });

  return {
    success: true,
    message: "OTP enviado (teste: 123456)",
  };
}

export async function verifyOtp(email: string, code: string): Promise<OtpResponse> {
  if (API_BASE_URL) {
    return fetch(`${API_BASE_URL}/auth/verify-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, code }),
    }).then((r) => r.json());
  }

  // MOCK MODE
  const otpData = getStorage(`otp_${email}`);

  if (!otpData || otpData.code !== code) {
    return { success: false, message: "Código inválido" };
  }

  const users = getStorage("users", SEED_USERS);
  const user = users.find((u: User) => u.email === email);

  if (!user) {
    return { success: false, message: "Usuário não encontrado" };
  }

  // Create fake token
  const token = btoa(`${email}:${Date.now()}`);
  setStorage("auth_token", token);
  setStorage("current_user_id", user.id);

  localStorage.removeItem(`otp_${email}`);

  return {
    success: true,
    message: "Autenticado com sucesso",
    token,
  };
}

export async function getMe(): Promise<User | null> {
  if (API_BASE_URL) {
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/users/me`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then((r) => r.json());
  }

  // MOCK MODE
  const userId = getStorage("current_user_id");
  if (!userId) return null;

  const users = getStorage("users", SEED_USERS);
  return users.find((u: User) => u.id === userId) || null;
}

export async function logout(): Promise<void> {
  localStorage.removeItem("auth_token");
  localStorage.removeItem("current_user_id");
}

// ============================================================================
// MACROS ENDPOINTS
// ============================================================================

export async function getMacros(): Promise<string[]> {
  if (API_BASE_URL) {
    return fetch(`${API_BASE_URL}/macros`).then((r) => r.json());
  }

  // MOCK MODE
  return getStorage("macros", SEED_MACROS);
}

// ============================================================================
// CHECKIN ENDPOINTS
// ============================================================================

export async function createCheckin(payload: Partial<Checkin>): Promise<Checkin> {
  if (API_BASE_URL) {
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/checkins`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    }).then((r) => r.json());
  }

  // MOCK MODE
  const currentUserId = getStorage("current_user_id");
  const checkin: Checkin = {
    id: `checkin-${Date.now()}`,
    created_at: new Date().toISOString(),
    subject_user_id: payload.subject_user_id || currentUserId,
    author_user_id: currentUserId,
    type: payload.type || "positive",
    macro: payload.macro || "",
    text: payload.text || "",
    visibility: payload.visibility || "visible",
    attachments: payload.attachments || [],
  };

  const checkins = getStorage("checkins", SEED_CHECKINS);
  checkins.push(checkin);
  setStorage("checkins", checkins);

  return checkin;
}

export async function listCheckins(filters?: {
  user_id?: string;
  macro?: string;
  type?: string;
  from_date?: string;
  to_date?: string;
}): Promise<Checkin[]> {
  if (API_BASE_URL) {
    const params = new URLSearchParams(filters as any);
    return fetch(`${API_BASE_URL}/checkins?${params}`).then((r) => r.json());
  }

  // MOCK MODE
  let checkins = getStorage("checkins", SEED_CHECKINS);

  if (filters?.user_id) {
    checkins = checkins.filter(
      (c: Checkin) =>
        c.subject_user_id === filters.user_id || c.author_user_id === filters.user_id
    );
  }

  if (filters?.macro) {
    checkins = checkins.filter((c: Checkin) => c.macro === filters.macro);
  }

  if (filters?.type) {
    checkins = checkins.filter((c: Checkin) => c.type === filters.type);
  }

  return checkins.sort(
    (a: Checkin, b: Checkin) =>
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );
}

// ============================================================================
// TEAM ENDPOINTS
// ============================================================================

export async function getTeam(): Promise<User[]> {
  if (API_BASE_URL) {
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/team`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then((r) => r.json());
  }

  // MOCK MODE
  const currentUser = await getMe();
  if (!currentUser) return [];

  const users = getStorage("users", SEED_USERS);
  return users.filter((u: User) => u.manager_id === currentUser.id);
}

export async function getSubTeam(userId: string): Promise<User[]> {
  if (API_BASE_URL) {
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/team/${userId}/subordinates`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then((r) => r.json());
  }

  // MOCK MODE
  const users = getStorage("users", SEED_USERS);
  return users.filter((u: User) => u.manager_id === userId);
}

// ============================================================================
// DASHBOARD ENDPOINTS
// ============================================================================

export async function getPersonalDashboard(userId: string) {
  if (API_BASE_URL) {
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/dashboard/personal/${userId}`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then((r) => r.json());
  }

  // MOCK MODE
  const users = getStorage("users", SEED_USERS);
  const user = users.find((u: User) => u.id === userId);

  if (!user) return null;

  const checkins = await listCheckins({ user_id: userId });

  return {
    user,
    checkins,
    stats: {
      total_checkins: checkins.length,
      positive_checkins: checkins.filter((c: Checkin) => c.type === "positive").length,
      improvement_checkins: checkins.filter((c: Checkin) => c.type === "improvement").length,
    },
  };
}

export async function generateSummary(payload: {
  user_id: string;
  period_from: string;
  period_to: string;
  audience: "self" | "manager" | "hr" | "public";
}): Promise<Summary> {
  if (API_BASE_URL) {
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/summaries`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    }).then((r) => r.json());
  }

  // MOCK MODE
  const summary: Summary = {
    id: `summary-${Date.now()}`,
    user_id: payload.user_id,
    period_from: payload.period_from,
    period_to: payload.period_to,
    audience: payload.audience,
    content: `Resumo de desenvolvimento de ${payload.period_from} a ${payload.period_to}. Progresso significativo em competências prioritárias.`,
    created_at: new Date().toISOString(),
  };

  const summaries = getStorage("summaries", []);
  summaries.push(summary);
  setStorage("summaries", summaries);

  return summary;
}

export async function getOrgDashboard(filters?: {
  from_date?: string;
  to_date?: string;
}): Promise<any> {
  if (API_BASE_URL) {
    const params = new URLSearchParams(filters as any);
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/dashboard/org?${params}`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then((r) => r.json());
  }

  // MOCK MODE
  const users = getStorage("users", SEED_USERS);
  const checkins = await listCheckins();

  return {
    total_users: users.length,
    total_checkins: checkins.length,
    checkins_by_macro: SEED_MACROS.map((macro) => ({
      macro,
      count: checkins.filter((c: Checkin) => c.macro === macro).length,
    })),
    users_by_role: {
      Colaborador: users.filter((u: User) => u.roles.includes("Colaborador")).length,
      Gestor: users.filter((u: User) => u.roles.includes("Gestor")).length,
      RH: users.filter((u: User) => u.roles.includes("RH")).length,
      Sócio: users.filter((u: User) => u.roles.includes("Sócio")).length,
    },
  };
}

// ============================================================================
// AVALIACAO DE CHECK-INS
// ============================================================================

export async function evaluateCheckin(
  checkin_id: string,
  status: "valid" | "invalid"
): Promise<{ success: boolean; message: string; points_modifier?: number }> {
  if (API_BASE_URL) {
    const token = getStorage("auth_token");
    return fetch(`${API_BASE_URL}/checkins/${checkin_id}/evaluate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status }),
    }).then((r) => r.json());
  }

  // MOCK MODE
  const checkins = getStorage("checkins", SEED_CHECKINS);
  const checkin = checkins.find((c: Checkin) => c.id === checkin_id);

  if (!checkin) {
    return { success: false, message: "Check-in nao encontrado" };
  }

  const points_modifier = status === "valid" ? 10 : -5;
  const currentUserId = getStorage("current_user_id");

  checkin.evaluation = {
    status,
    evaluated_by: currentUserId,
    evaluated_at: new Date().toISOString(),
    points_modifier,
  };

  setStorage("checkins", checkins);

  return {
    success: true,
    message: `Check-in marcado como ${status === "valid" ? "valido" : "invalido"}`,
    points_modifier,
  };
}

// ============================================================================
// INITIALIZATION
// ============================================================================

initializeStorage();
