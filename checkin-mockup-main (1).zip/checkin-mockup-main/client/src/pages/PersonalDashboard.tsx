import { useState } from "react";
import { useLocation } from "wouter";
import { BookOpen, Lightbulb, AlertCircle, ArrowRight } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import Card from "@/components/Card";
import PriorityCompetencies, { PriorityCompetency } from "@/components/PriorityCompetencies";
import EvolutionTrail, { EvolutionPoint } from "@/components/EvolutionTrail";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const mockPriorityCompetencies: PriorityCompetency[] = [
  {
    name: "Liderança",
    priority: 1,
    evolution: 8,
    lastUpdate: "2026-02-08",
  },
  {
    name: "Comunicação",
    priority: 2,
    evolution: -2,
    lastUpdate: "2026-02-06",
  },
  {
    name: "Resolução de Problemas",
    priority: 3,
    evolution: 5,
    lastUpdate: "2026-02-04",
  },
];

const mockEvolutionPoints: EvolutionPoint[] = [
  { date: "Jan", value: 45, isPriority: false },
  { date: "Fev", value: 52, isPriority: true },
  { date: "Mar", value: 48, isPriority: false },
  { date: "Abr", value: 61, isPriority: true },
  { date: "Mai", value: 58, isPriority: false },
  { date: "Jun", value: 68, isPriority: true },
];

const competencyData = [
  { name: "Liderança", value: 85 },
  { name: "Comunicação", value: 62 },
  { name: "Resolução", value: 78 },
  { name: "Trabalho em Equipe", value: 71 },
  { name: "Inovação", value: 55 },
];

const suggestions = [
  {
    type: "course",
    title: "Liderança Estratégica para Gestores",
    description: "Desenvolva habilidades avançadas de liderança e visão estratégica",
    duration: "4 semanas",
    icon: BookOpen,
  },
  {
    type: "action",
    title: "Mentoria com Sênior",
    description: "Sessões mensais de mentoria para aprofundar conhecimentos",
    duration: "Contínuo",
    icon: Lightbulb,
  },
  {
    type: "book",
    title: "Crucial Conversations",
    description: "Melhorar comunicação em situações difíceis",
    duration: "Leitura: 2 semanas",
    icon: BookOpen,
  },
];

const alerts = [
  {
    severity: "warning",
    message: "Baixo registro em Comunicação nas últimas 2 semanas",
  },
  {
    severity: "info",
    message: "Você está progredindo bem em Liderança! Continue assim.",
  },
];

export default function PersonalDashboard() {
  const [, setLocation] = useLocation();
  const [userName] = useState("João Silva");

  const handleLogout = () => {
    setLocation("/login");
  };

  return (
    <DashboardLayout
      userName={userName}
      userRole="Gestor"
      onLogout={handleLogout}
    >
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Seu Dashboard Pessoal</h1>
        <p className="text-muted-foreground">
          Acompanhe seu desenvolvimento com foco nas competências prioritárias.
        </p>
      </div>

      {/* Alerts */}
      <div className="space-y-3 mb-8">
        {alerts.map((alert, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-3 p-4 rounded-lg ${
              alert.severity === "warning"
                ? "bg-amber-50 border border-amber-200"
                : "bg-blue-50 border border-blue-200"
            }`}
          >
            <AlertCircle
              size={18}
              className={alert.severity === "warning" ? "text-amber-600" : "text-blue-600"}
            />
            <p
              className={alert.severity === "warning" ? "text-amber-900" : "text-blue-900"}
            >
              {alert.message}
            </p>
          </div>
        ))}
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6 mb-8">
        {/* Left Column: Priority Competencies */}
        <div className="lg:col-span-1">
          <Card>
            <h2 className="text-lg font-bold text-foreground mb-4">Competências Prioritárias</h2>
            <PriorityCompetencies competencies={mockPriorityCompetencies} />
          </Card>
        </div>

        {/* Middle Column: Evolution Trail */}
        <div className="lg:col-span-2">
          <Card>
            <h2 className="text-lg font-bold text-foreground mb-4">Trilha de Evolução</h2>
            <EvolutionTrail points={mockEvolutionPoints} />
          </Card>
        </div>
      </div>

      {/* Competency Distribution */}
      <Card className="mb-8">
        <h2 className="text-lg font-bold text-foreground mb-4">Distribuição de Competências</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={competencyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="name" stroke="#6B7280" />
            <YAxis stroke="#6B7280" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#FFFFFF",
                border: "1px solid #E5E7EB",
                borderRadius: "8px",
              }}
            />
            <Bar dataKey="value" fill="#4B5563" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Suggestions */}
      <div className="mb-8">
        <h2 className="text-lg font-bold text-foreground mb-4">Sugestões de Desenvolvimento</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {suggestions.map((suggestion, idx) => {
            const Icon = suggestion.icon;
            return (
              <Card key={idx} className="hover:shadow-md">
                <div className="flex items-start justify-between mb-3">
                  <Icon size={24} className="text-accent" />
                  <span className="text-xs font-medium text-muted-foreground">
                    {suggestion.duration}
                  </span>
                </div>
                <h3 className="font-bold text-foreground mb-2">{suggestion.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{suggestion.description}</p>
                <button className="flex items-center gap-2 text-accent hover:text-accent/80 text-sm font-medium transition-colors">
                  Saiba mais
                  <ArrowRight size={16} />
                </button>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="text-center">
          <p className="text-2xl font-bold text-accent">12</p>
          <p className="text-sm text-muted-foreground mt-1">Registros</p>
        </Card>
        <Card className="text-center">
          <p className="text-2xl font-bold text-accent">68%</p>
          <p className="text-sm text-muted-foreground mt-1">Evolução Geral</p>
        </Card>
        <Card className="text-center">
          <p className="text-2xl font-bold text-accent">+8</p>
          <p className="text-sm text-muted-foreground mt-1">Liderança</p>
        </Card>
        <Card className="text-center">
          <p className="text-2xl font-bold text-accent">3</p>
          <p className="text-sm text-muted-foreground mt-1">Prioridades</p>
        </Card>
      </div>
    </DashboardLayout>
  );
}
