import { useState } from "react";
import { useLocation } from "wouter";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";
import DashboardLayout from "@/components/DashboardLayout";
import Card from "@/components/Card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const recordsByArea = [
  { name: "Tecnologia", value: 145 },
  { name: "Vendas", value: 98 },
  { name: "RH", value: 67 },
  { name: "Financeiro", value: 54 },
  { name: "Operações", value: 76 },
];

const competencyDistribution = [
  { name: "Liderança", value: 28 },
  { name: "Comunicação", value: 22 },
  { name: "Resolução de Problemas", value: 25 },
  { name: "Trabalho em Equipe", value: 18 },
  { name: "Inovação", value: 7 },
];

const consistencyTrend = [
  { month: "Jan", registros: 120, usuarios: 45 },
  { month: "Fev", registros: 145, usuarios: 52 },
  { month: "Mar", registros: 168, usuarios: 58 },
  { month: "Abr", registros: 192, usuarios: 62 },
  { month: "Mai", registros: 215, usuarios: 68 },
  { month: "Jun", registros: 248, usuarios: 75 },
];

const COLORS = ["#4B5563", "#6B7280", "#9CA3AF", "#D1D5DB", "#E5E7EB"];

export default function Dashboards() {
  const [, setLocation] = useLocation();
  const [userName] = useState("João Silva");
  const [selectedPeriod, setSelectedPeriod] = useState("mes");
  const [selectedArea, setSelectedArea] = useState("todas");
  const [selectedCycle, setSelectedCycle] = useState("atual");

  const handleLogout = () => {
    setLocation("/login");
  };

  return (
    <DashboardLayout
      userName={userName}
      userRole="RH"
      onLogout={handleLogout}
    >
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Dashboards</h1>
        <p className="text-muted-foreground">
          Visão geral das métricas de desenvolvimento e consistência de registros da organização.
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="semana">Última Semana</SelectItem>
            <SelectItem value="mes">Último Mês</SelectItem>
            <SelectItem value="trimestre">Último Trimestre</SelectItem>
            <SelectItem value="ano">Último Ano</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedArea} onValueChange={setSelectedArea}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Área" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todas">Todas as Áreas</SelectItem>
            <SelectItem value="tech">Tecnologia</SelectItem>
            <SelectItem value="vendas">Vendas</SelectItem>
            <SelectItem value="rh">RH</SelectItem>
            <SelectItem value="financeiro">Financeiro</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedCycle} onValueChange={setSelectedCycle}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Ciclo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="atual">Ciclo Atual</SelectItem>
            <SelectItem value="anterior">Ciclo Anterior</SelectItem>
            <SelectItem value="todos">Todos os Ciclos</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <Card className="text-center">
          <p className="text-3xl font-bold text-accent">840</p>
          <p className="text-sm text-muted-foreground mt-2">Registros Total</p>
        </Card>
        <Card className="text-center">
          <p className="text-3xl font-bold text-accent">75</p>
          <p className="text-sm text-muted-foreground mt-2">Usuários Ativos</p>
        </Card>
        <Card className="text-center">
          <p className="text-3xl font-bold text-accent">11.2</p>
          <p className="text-sm text-muted-foreground mt-2">Média por Pessoa</p>
        </Card>
        <Card className="text-center">
          <p className="text-3xl font-bold text-accent">68%</p>
          <p className="text-sm text-muted-foreground mt-2">Consistência</p>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        {/* Registros por Área */}
        <Card>
          <h3 className="font-bold text-foreground mb-4">Registros por Área</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={recordsByArea}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="name" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E5E7EB",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="value" fill="#4B5563" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Distribuição de Competências */}
        <Card>
          <h3 className="font-bold text-foreground mb-4">Distribuição de Competências</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={competencyDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={80}
                fill="#4B5563"
                dataKey="value"
              >
                {competencyDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Consistency Trend */}
      <Card className="mb-8">
        <h3 className="font-bold text-foreground mb-4">Consistência de Registros ao Longo do Tempo</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={consistencyTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis dataKey="month" stroke="#6B7280" />
            <YAxis stroke="#6B7280" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#FFFFFF",
                border: "1px solid #E5E7EB",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="registros"
              stroke="#4B5563"
              strokeWidth={2}
              dot={{ fill: "#4B5563", r: 4 }}
              name="Registros"
            />
            <Line
              type="monotone"
              dataKey="usuarios"
              stroke="#9CA3AF"
              strokeWidth={2}
              dot={{ fill: "#9CA3AF", r: 4 }}
              name="Usuários Ativos"
            />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Insights */}
      <Card className="bg-blue-50 border-blue-200">
        <h3 className="font-bold text-blue-900 mb-2">Insights</h3>
        <ul className="text-sm text-blue-800 space-y-2">
          <li>• Tecnologia lidera com 145 registros, representando 17% do total</li>
          <li>• Liderança é a competência mais desenvolvida (28% dos registros)</li>
          <li>• Tendência positiva: 106% de crescimento nos últimos 6 meses</li>
          <li>• Consistência geral de 68% indica engajamento moderado à alto</li>
        </ul>
      </Card>
    </DashboardLayout>
  );
}
