import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { ArrowLeft, Eye, EyeOff, Plus, Download } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import Card from "@/components/Card";
import CheckinEvaluationButton from "@/components/CheckinEvaluationButton";
import { Button } from "@/components/ui/button";

interface CheckinRecord {
  id: string;
  date: string;
  type: "positivo" | "melhoria";
  competency: string;
  description: string;
  visible: boolean;
  isPrivate: boolean;
  evaluation?: "valid" | "invalid" | null;
}

const mockRecords: CheckinRecord[] = [
  {
    id: "1",
    date: "2026-02-08",
    type: "positivo",
    competency: "Liderança",
    description: "Coordenou com sucesso a reunião de planejamento trimestral",
    visible: true,
    isPrivate: false,
  },
  {
    id: "2",
    date: "2026-02-06",
    type: "melhoria",
    competency: "Comunicação",
    description: "Precisa melhorar a clareza nas apresentações técnicas",
    visible: false,
    isPrivate: true,
  },
  {
    id: "3",
    date: "2026-02-04",
    type: "positivo",
    competency: "Resolução de Problemas",
    description: "Implementou solução inovadora para otimizar processos",
    visible: true,
    isPrivate: false,
  },
];

export default function ManagedProgress() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/gerido/:id");
  const [userName] = useState("João Silva");
  const [records, setRecords] = useState<CheckinRecord[]>(mockRecords);
  
  // Dados dos geridos (simulado)
  const managedPeople: Record<string, { name: string; role: string }> = {
    "1": { name: "Maria Santos", role: "Analista Senior" },
    "1-1": { name: "Lucas Ferreira", role: "Analista Pleno" },
    "1-2": { name: "Sofia Mendes", role: "Analista Junior" },
    "2": { name: "Pedro Oliveira", role: "Desenvolvedor" },
    "3": { name: "Ana Costa", role: "Designer" },
  };
  
  const managedId = params?.id || "1";
  const managedName = managedPeople[managedId]?.name || "Usuário";

  const handleLogout = () => {
    setLocation("/login");
  };

  const handleNewRecord = () => {
    setLocation("/novo-registro");
  };

  const handleGenerateSummary = () => {
    setLocation("/resumo");
  };

  const handleEvaluate = (recordId: string, status: "valid" | "invalid") => {
    setRecords(records.map(r => r.id === recordId ? { ...r, evaluation: status } : r));
  };

  return (
    <DashboardLayout
      userName={userName}
      userRole="Gestor"
      onLogout={handleLogout}
    >
      {/* Page Header */}
      <div className="mb-8">
        <button
          onClick={() => setLocation("/meu-time")}
          className="flex items-center gap-2 text-accent hover:text-accent/80 mb-4 transition-colors"
        >
          <ArrowLeft size={18} />
          <span className="text-sm font-medium">Voltar para Meu Time</span>
        </button>
        <h1 className="text-3xl font-bold text-foreground mb-2">Progresso de {managedName}</h1>
        <p className="text-muted-foreground">
          Acompanhe todos os registros de desenvolvimento desta pessoa, incluindo registros privados.
        </p>
      </div>

      {/* Actions */}
      <div className="flex gap-4 mb-8">
        <Button
          onClick={handleNewRecord}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus size={18} className="mr-2" />
          Novo Registro para {managedName}
        </Button>
        <Button
          onClick={handleGenerateSummary}
          variant="outline"
        >
          <Download size={18} className="mr-2" />
          Gerar Resumo do Período
        </Button>
      </div>

      {/* Records List */}
      <div className="space-y-4">
        {records.length === 0 ? (
          <Card className="text-center py-12">
            <p className="text-muted-foreground">Nenhum registro encontrado.</p>
          </Card>
        ) : (
          records.map((record) => (
            <Card key={record.id} className="hover:shadow-md">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        record.type === "positivo"
                          ? "bg-green-100 text-green-800"
                          : "bg-amber-100 text-amber-800"
                      }`}
                    >
                      {record.type === "positivo" ? "Positivo" : "Melhoria"}
                    </span>
                    <span className="text-sm font-medium text-accent">{record.competency}</span>
                    <span className="text-xs text-muted-foreground">{record.date}</span>
                  </div>
                  <p className="text-foreground">{record.description}</p>
                </div>

                <div className="flex items-center gap-3 ml-4">
                  <CheckinEvaluationButton
                    checkinId={record.id}
                    currentEvaluation={record.evaluation || null}
                    onEvaluate={(status) => {
                      setRecords(records.map(r => r.id === record.id ? { ...r, evaluation: status } : r));
                    }}
                  />
                  {record.isPrivate ? (
                    <div className="flex items-center gap-1 px-3 py-1 bg-red-50 rounded-lg">
                      <EyeOff size={16} className="text-red-600" />
                      <span className="text-xs font-medium text-red-600">Privado</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 px-3 py-1 bg-green-50 rounded-lg">
                      <Eye size={16} className="text-green-600" />
                      <span className="text-xs font-medium text-green-600">Visível</span>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Development Suggestions */}
      <Card className="mt-8 mb-8 bg-blue-50 border-blue-200">
        <h2 className="text-lg font-bold text-blue-900 mb-4">Sugestões de Desenvolvimento</h2>
        <div className="space-y-3">
          <div className="p-3 bg-white rounded border border-blue-100">
            <p className="text-sm font-medium text-blue-900">Aprofundar em Liderança</p>
            <p className="text-xs text-blue-800 mt-1">Baseado no progresso positivo recente nesta competência</p>
          </div>
          <div className="p-3 bg-white rounded border border-blue-100">
            <p className="text-sm font-medium text-blue-900">Melhorar Comunicação</p>
            <p className="text-xs text-blue-800 mt-1">Registros indicam oportunidade de desenvolvimento nesta área</p>
          </div>
        </div>
      </Card>

      {/* Summary Stats */}
      {records.length > 0 && (
        <div className="grid grid-cols-4 gap-4 mt-8">
          <Card className="text-center">
            <p className="text-2xl font-bold text-accent">{records.length}</p>
            <p className="text-sm text-muted-foreground mt-1">Total</p>
          </Card>
          <Card className="text-center">
            <p className="text-2xl font-bold text-accent">
              {records.filter((r) => r.type === "positivo").length}
            </p>
            <p className="text-sm text-muted-foreground mt-1">Positivos</p>
          </Card>
          <Card className="text-center">
            <p className="text-2xl font-bold text-accent">
              {records.filter((r) => r.type === "melhoria").length}
            </p>
            <p className="text-sm text-muted-foreground mt-1">Melhorias</p>
          </Card>
          <Card className="text-center">
            <p className="text-2xl font-bold text-accent">
              {records.filter((r) => !r.isPrivate).length}
            </p>
            <p className="text-sm text-muted-foreground mt-1">Visíveis</p>
          </Card>
        </div>
      )}

      {/* Info Box */}
      <Card className="mt-8 bg-blue-50 border-blue-200">
        <p className="text-sm text-blue-900">
          <strong>Nota:</strong> Como gestor, você pode visualizar todos os registros, incluindo os
          privados. Registros privados não são visíveis para o gerido, mas contribuem para a análise
          de desenvolvimento.
        </p>
      </Card>
    </DashboardLayout>
  );
}
