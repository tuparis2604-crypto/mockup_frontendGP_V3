import { useState } from "react";
import { useLocation } from "wouter";
import { Upload, X } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import Card from "@/components/Card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

export default function NewRecord() {
  const [, setLocation] = useLocation();
  const [userName] = useState("João Silva");
  const [userRole] = useState("Gestor");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("positivo");
  const [competency, setCompetency] = useState("");
  const [visible, setVisible] = useState(true);
  const [attachments, setAttachments] = useState<string[]>([]);

  const handleLogout = () => {
    setLocation("/login");
  };

  const handleAddAttachment = () => {
    setAttachments([...attachments, `Arquivo ${attachments.length + 1}`]);
  };

  const handleRemoveAttachment = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    // Simulando salvamento
    setLocation("/progresso");
  };

  const competencies = [
    "Liderança",
    "Comunicação",
    "Resolução de Problemas",
    "Trabalho em Equipe",
    "Inovação",
    "Gestão de Tempo",
  ];

  const isFormValid = description.trim() && competency && type;

  return (
    <DashboardLayout
      userName={userName}
      userRole={userRole}
      onLogout={handleLogout}
    >
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Novo Registro</h1>
        <p className="text-muted-foreground">
          Registre um fato observado para contribuir ao seu desenvolvimento contínuo.
        </p>
      </div>

      <div className="max-w-2xl">
        <Card>
          <form className="space-y-6">
            {/* Gerido Selection (apenas para gestores) */}
            {(userRole === "Gestor" || userRole === "RH" || userRole === "Sócio") && (
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Registrar para:
                </label>
                <Select defaultValue="self">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="self">Mim mesmo</SelectItem>
                    <SelectItem value="maria">Maria Santos</SelectItem>
                    <SelectItem value="pedro">Pedro Oliveira</SelectItem>
                    <SelectItem value="ana">Ana Costa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Descreva o fato observado *
              </label>
              <Textarea
                placeholder="Ex: Colaborou de forma excepcional no projeto X, demonstrando liderança e iniciativa..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full min-h-32"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Seja específico e descreva o contexto, ações e resultados observados.
              </p>
            </div>

            {/* Type Selection */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Tipo de Registro *
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="type"
                    value="positivo"
                    checked={type === "positivo"}
                    onChange={(e) => setType(e.target.value)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm">
                    <span className="font-medium text-foreground">✓ Positivo</span>
                    <span className="text-muted-foreground ml-1">(força, sucesso)</span>
                  </span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="type"
                    value="melhoria"
                    checked={type === "melhoria"}
                    onChange={(e) => setType(e.target.value)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm">
                    <span className="font-medium text-foreground">⚠ Ponto de Melhoria</span>
                    <span className="text-muted-foreground ml-1">(desenvolvimento)</span>
                  </span>
                </label>
              </div>
            </div>

            {/* Competency */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Macrocompetência *
              </label>
              <Select value={competency} onValueChange={setCompetency}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma competência" />
                </SelectTrigger>
                <SelectContent>
                  {competencies.map((comp) => (
                    <SelectItem key={comp} value={comp}>
                      {comp}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Visibility Toggle */}
            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="font-medium text-foreground">Visível para o gerido</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Se desativado, apenas você e administradores verão este registro.
                </p>
              </div>
              <Switch checked={visible} onCheckedChange={setVisible} />
            </div>

            {/* Attachments */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Anexos (opcional)
              </label>
              <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:bg-secondary/50 transition-colors">
                <Upload size={24} className="mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Arraste arquivos ou links relevantes
                </p>
                <Button
                  type="button"
                  onClick={handleAddAttachment}
                  variant="outline"
                  size="sm"
                >
                  Adicionar Arquivo
                </Button>
              </div>

              {attachments.length > 0 && (
                <div className="mt-4 space-y-2">
                  {attachments.map((attachment, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg"
                    >
                      <span className="text-sm text-foreground">{attachment}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveAttachment(index)}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <X size={18} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Info Box */}
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-900">
                <strong>Privacidade:</strong> Registros privados não ficam visíveis para o gerido, mas
                são considerados na análise de desenvolvimento.
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-4 pt-4">
              <Button
                onClick={handleSave}
                disabled={!isFormValid}
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Salvar Registro
              </Button>
              <Button
                onClick={() => setLocation("/progresso")}
                variant="outline"
                className="flex-1"
              >
                Cancelar
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </DashboardLayout>
  );
}
