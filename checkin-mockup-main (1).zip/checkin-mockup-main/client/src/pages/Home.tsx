import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { ChevronRight, TrendingUp, Plus, FileText, Users, BarChart3, AlertCircle, BookOpen, Zap } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import Card from "@/components/Card";
import { Button } from "@/components/ui/button";
import { getMe, logout, getHighestRole } from "@/lib/api";
import type { User } from "@/lib/api";

const mockAlerts = [
  {
    id: "1",
    type: "warning",
    title: "Baixo Registro em Comunicação",
    description: "Você não registrou nada sobre Comunicação nas últimas 2 semanas.",
  },
  {
    id: "2",
    type: "success",
    title: "Marco Atingido: Liderança +10 pontos",
    description: "Parabéns! Você evoluiu significativamente em Liderança este mês.",
  },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await getMe();
        if (currentUser) {
          setUser(currentUser);
        } else {
          setLocation("/login");
        }
      } catch (error) {
        console.error("Erro ao carregar usuário:", error);
        setLocation("/login");
      } finally {
        setLoading(false);
      }
    };

    loadUser();
  }, [setLocation]);

  const handleLogout = async () => {
    await logout();
    setLocation("/login");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const isManager = user.roles.includes("Gestor");
  const isExecutive = user.roles.includes("RH") || user.roles.includes("Sócio");

  return (
    <DashboardLayout
      userName={user.name}
      userRole={getHighestRole(user.roles)}
      onLogout={handleLogout}
    >
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Bem-vindo, {user.name}!</h1>
        <p className="text-muted-foreground">
          Registre fatos ao longo do período para facilitar o acompanhamento e desenvolvimento contínuo.
        </p>
      </div>

      {/* Alertas em Destaque */}
      <div className="mb-8">
        <h2 className="text-lg font-bold text-foreground mb-4">Avisos Recentes</h2>
        <div className="space-y-3">
          {mockAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`flex gap-3 p-4 rounded-lg border-l-4 ${
                alert.type === "warning"
                  ? "bg-amber-50 border-l-amber-500"
                  : "bg-green-50 border-l-green-500"
              }`}
            >
              <AlertCircle
                size={20}
                className={alert.type === "warning" ? "text-amber-600" : "text-green-600"}
              />
              <div>
                <p className={`font-bold text-sm ${alert.type === "warning" ? "text-amber-900" : "text-green-900"}`}>
                  {alert.title}
                </p>
                <p className={`text-xs mt-1 ${alert.type === "warning" ? "text-amber-800" : "text-green-800"}`}>
                  {alert.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <Button variant="outline" className="w-full mt-4">
          Ver Todos os Avisos
        </Button>
      </div>

      {/* Navegação Rápida */}
      <div className="mb-8">
        <h2 className="text-lg font-bold text-foreground mb-4">Navegação Rápida</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Meu Progresso */}
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setLocation("/progresso")}
          >
            <div className="flex items-start justify-between mb-3">
              <TrendingUp size={24} className="text-accent" />
              <ChevronRight size={20} className="text-muted-foreground" />
            </div>
            <h3 className="font-bold text-foreground mb-1">Meu Progresso</h3>
            <p className="text-xs text-muted-foreground mb-4">Acompanhe seu desenvolvimento</p>
            <p className="text-sm font-semibold text-accent">12 registros este período</p>
          </Card>

          {/* Novo Registro */}
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setLocation("/novo-registro")}
          >
            <div className="flex items-start justify-between mb-3">
              <Plus size={24} className="text-accent" />
              <ChevronRight size={20} className="text-muted-foreground" />
            </div>
            <h3 className="font-bold text-foreground mb-1">Novo Registro</h3>
            <p className="text-xs text-muted-foreground mb-4">Registre um fato observado</p>
            <p className="text-sm font-semibold text-accent">Rápido e simples</p>
          </Card>

          {/* Dashboard Pessoal */}
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setLocation("/dashboard-pessoal")}
          >
            <div className="flex items-start justify-between mb-3">
              <Zap size={24} className="text-accent" />
              <ChevronRight size={20} className="text-muted-foreground" />
            </div>
            <h3 className="font-bold text-foreground mb-1">Dashboard Pessoal</h3>
            <p className="text-xs text-muted-foreground mb-4">Análise de seu desenvolvimento</p>
            <p className="text-sm font-semibold text-accent">Métricas e sugestões</p>
          </Card>

          {/* Meu Time - Apenas para Gestores */}
          {isManager && (
            <Card
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setLocation("/meu-time")}
            >
              <div className="flex items-start justify-between mb-3">
                <Users size={24} className="text-accent" />
                <ChevronRight size={20} className="text-muted-foreground" />
              </div>
              <h3 className="font-bold text-foreground mb-1">Meu Time</h3>
              <p className="text-xs text-muted-foreground mb-4">Acompanhe seus geridos</p>
              <p className="text-sm font-semibold text-accent">3 colaboradores</p>
            </Card>
          )}

          {/* Dashboards - Apenas para RH/Sócios */}
          {isExecutive && (
            <Card
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setLocation("/dashboards")}
            >
              <div className="flex items-start justify-between mb-3">
                <BarChart3 size={24} className="text-accent" />
                <ChevronRight size={20} className="text-muted-foreground" />
              </div>
              <h3 className="font-bold text-foreground mb-1">Dashboards</h3>
              <p className="text-xs text-muted-foreground mb-4">Visão organizacional</p>
              <p className="text-sm font-semibold text-accent">Métricas globais</p>
            </Card>
          )}
        </div>
      </div>

      {/* Info Box */}
      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-900">
        <p>
          <strong>Modo MOCK:</strong> Todos os dados são salvos localmente no seu navegador. Ao conectar a um backend real, os dados serão sincronizados com o servidor.
        </p>
      </div>
    </DashboardLayout>
  );
}
