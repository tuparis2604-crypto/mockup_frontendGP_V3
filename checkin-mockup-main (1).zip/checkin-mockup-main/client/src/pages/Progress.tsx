import { useState } from "react";
import { useLocation } from "wouter";
import { Eye, EyeOff, Download } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import Card from "@/components/Card";
import PriorityCompetencies, { PriorityCompetency } from "@/components/PriorityCompetencies";
import EvolutionTrail, { EvolutionPoint } from "@/components/EvolutionTrail";
import SinuousTrail, { TrailPoint } from "@/components/SinuousTrail";
import GamifiedTrail, { GamifiedTrailPoint } from "@/components/GamifiedTrail";
import GameTrail, { TrailMilestone } from "@/components/GameTrail";
import DevelopmentJourney, { JourneyMilestone } from "@/components/DevelopmentJourney";
import ContinuousEvolution, { EvolutionSuggestion } from "@/components/ContinuousEvolution";
import JornadaDeEvolucao from "@/components/JornadaDeEvolucao";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface CheckinRecord {
  id: string;
  date: string;
  type: "positivo" | "melhoria";
  competency: string;
  description: string;
  visible: boolean;
}

const mockPriorityCompetencies: PriorityCompetency[] = [
  {
    name: "Liderança",
    priority: 1,
    evolution: 8,
    lastUpdate: "2026-02-08",
  },
  {
    name: "Comunicação",
    priority: 2,
    evolution: -2,
    lastUpdate: "2026-02-06",
  },
  {
    name: "Resolução de Problemas",
    priority: 3,
    evolution: 5,
    lastUpdate: "2026-02-04",
  },
];

const mockEvolutionPoints: EvolutionPoint[] = [
  { date: "Jan", value: 45, isPriority: false },
  { date: "Fev", value: 52, isPriority: true },
  { date: "Mar", value: 48, isPriority: false },
  { date: "Abr", value: 61, isPriority: true },
  { date: "Mai", value: 58, isPriority: false },
  { date: "Jun", value: 68, isPriority: true },
];

const mockTrailPoints: TrailPoint[] = [
  { date: "Sem 1", value: 45, isPriority: false },
  { date: "Sem 2", value: 48, isPriority: false },
  { date: "Sem 3", value: 52, isPriority: true },
  { date: "Sem 4", value: 50, isPriority: false },
  { date: "Sem 5", value: 58, isPriority: true },
  { date: "Sem 6", value: 61, isPriority: true },
  { date: "Sem 7", value: 55, isPriority: false },
  { date: "Sem 8", value: 68, isPriority: true },
];

const mockGamifiedTrail: GamifiedTrailPoint[] = [
  { week: "Sem 1", score: 45, isPriority: false },
  { week: "Sem 2", score: 48, isPriority: false },
  { week: "Sem 3", score: 52, isPriority: true },
  { week: "Sem 4", score: 50, isPriority: false },
  { week: "Sem 5", score: 58, isPriority: true },
  { week: "Sem 6", score: 61, isPriority: true },
  { week: "Sem 7", score: 55, isPriority: false },
  { week: "Sem 8", score: 68, isPriority: true },
];

const mockMilestones: TrailMilestone[] = [
  {
    id: "1",
    position: 15,
    title: "Primeiro Passo",
    description: "Registre seu primeiro fato de desenvolvimento",
    type: "checkpoint",
    completed: true,
  },
  {
    id: "2",
    position: 30,
    title: "Liderança +5",
    description: "Atinja 5 pontos em Liderança",
    type: "goal",
    completed: true,
  },
  {
    id: "3",
    position: 50,
    title: "Meio do Caminho",
    description: "Você já está na metade da jornada!",
    type: "achievement",
    completed: true,
  },
  {
    id: "4",
    position: 75,
    title: "Comunicação Mestre",
    description: "Domine a competência de Comunicação",
    type: "goal",
    completed: false,
  },
  {
    id: "5",
    position: 100,
    title: "Jornada Completa",
    description: "Atinja o máximo desenvolvimento",
    type: "achievement",
    completed: false,
  },
];

const mockJourneyMilestones: JourneyMilestone[] = [
  {
    id: "j1",
    position: 20,
    type: "suggestion",
    title: "Cursos de Liderança",
    description: "Explore técnicas avançadas de liderança estratégica",
    isPriority: true,
    completed: true,
  },
  {
    id: "j2",
    position: 35,
    type: "suggestion",
    title: "Mentoria com Sênior",
    description: "Sessões mensais para aprofundar conhecimentos",
    isPriority: true,
    completed: true,
  },
  {
    id: "j3",
    position: 50,
    type: "achievement",
    title: "Meio da Jornada",
    description: "Você atingiu 50% de progresso!",
    isPriority: false,
    completed: true,
  },
  {
    id: "j4",
    position: 65,
    type: "suggestion",
    title: "Leitura: Crucial Conversations",
    description: "Melhore comunicação em situações difíceis",
    isPriority: false,
    completed: false,
  },
  {
    id: "j5",
    position: 80,
    type: "suggestion",
    title: "Workshop de Inovação",
    description: "Desenvolva pensamento criativo e soluções inovadoras",
    isPriority: true,
    completed: false,
  },
];

const mockEvolutionSuggestions: EvolutionSuggestion[] = [
  {
    id: "e1",
    title: "Cursos de Liderança Estratégica",
    description: "Explore técnicas avançadas de liderança",
    type: "course",
    isPriority: true,
    completed: true,
    impactBoost: 15,
  },
  {
    id: "e2",
    title: "Mentoria com Sênior",
    description: "Sessões mensais para aprofundar conhecimentos",
    type: "mentoring",
    isPriority: true,
    completed: true,
    impactBoost: 12,
  },
  {
    id: "e3",
    title: "Leitura: Crucial Conversations",
    description: "Melhore comunicação em situações difíceis",
    type: "book",
    isPriority: false,
    completed: false,
    impactBoost: 8,
  },
  {
    id: "e4",
    title: "Ação: Liderar um projeto de inovação",
    description: "Pratique liderança em um projeto real",
    type: "action",
    isPriority: true,
    completed: false,
    impactBoost: 20,
  },
  {
    id: "e5",
    title: "Workshop de Comunicação Não-Violenta",
    description: "Desenvolva habilidades de comunicação empática",
    type: "course",
    isPriority: false,
    completed: false,
    impactBoost: 10,
  },
];

const mockRecords: CheckinRecord[] = [
  {
    id: "1",
    date: "2026-02-08",
    type: "positivo",
    competency: "Liderança",
    description: "Coordenou com sucesso a reunião de planejamento trimestral",
    visible: true,
  },
  {
    id: "2",
    date: "2026-02-06",
    type: "melhoria",
    competency: "Comunicação",
    description: "Precisa melhorar a clareza nas apresentações técnicas",
    visible: false,
  },
  {
    id: "3",
    date: "2026-02-04",
    type: "positivo",
    competency: "Resolução de Problemas",
    description: "Implementou solução inovadora para otimizar processos",
    visible: true,
  },
  {
    id: "4",
    date: "2026-02-01",
    type: "positivo",
    competency: "Trabalho em Equipe",
    description: "Colaboração excepcional no projeto X com o time de design",
    visible: true,
  },
];

export default function Progress() {
  const [, setLocation] = useLocation();
  const [userName] = useState("João Silva");
  const [selectedPeriod, setSelectedPeriod] = useState("mes");
  const [selectedCompetency, setSelectedCompetency] = useState("todas");
  const [showOnlyPriority, setShowOnlyPriority] = useState(false);
  const [records] = useState(mockRecords);

  const handleLogout = () => {
    setLocation("/login");
  };

  const filteredRecords = records.filter((record) => {
    if (selectedCompetency !== "todas" && record.competency !== selectedCompetency) {
      return false;
    }
    return true;
  });

  const competencies = Array.from(new Set(records.map((r) => r.competency)));

  return (
    <DashboardLayout
      userName={userName}
      userRole="Gestor"
      onLogout={handleLogout}
    >
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Meu Progresso</h1>
        <p className="text-muted-foreground">
          Visualize sua trilha de desenvolvimento e acompanhe a evolução de suas competências.
        </p>
      </div>

      {/* Jornada de Evolução Principal */}
      <Card className="mb-8">
        <h2 className="text-lg font-bold text-foreground mb-2">Jornada de Evolução</h2>
        <p className="text-sm text-muted-foreground mb-6">
          Acompanhe sua progressão contínua. Cada check-in positivo o move em direção ao desenvolvimento pleno.
        </p>
        <JornadaDeEvolucao
          currentPoints={68}
          maxPoints={100}
          validCheckins={13}
          alerts={[
            "Muitos feedbacks positivos apenas. Faça construtivos também, autocrítica é importante.",
          ]}
          trend="positive"
        />
      </Card>

      {/* Botão Gerar Resumo */}
      <div className="mb-8">
        <button className="px-6 py-3 bg-accent text-accent-foreground rounded-lg font-medium hover:bg-accent/90 transition-colors">
          Gerar Resumo do Período
        </button>
      </div>

      {/* Competências Prioritárias */}
      <Card className="mb-8">
        <h2 className="text-lg font-bold text-foreground mb-4">Competências Prioritárias</h2>
        <PriorityCompetencies competencies={mockPriorityCompetencies} compact />
      </Card>

      {/* Filters and Actions */}
      <div className="flex flex-col gap-4 mb-8">
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semana">Última Semana</SelectItem>
              <SelectItem value="mes">Último Mês</SelectItem>
              <SelectItem value="trimestre">Último Trimestre</SelectItem>
              <SelectItem value="ano">Último Ano</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedCompetency} onValueChange={setSelectedCompetency}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Competência" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as Competências</SelectItem>
              {competencies.map((comp) => {
                const isPriority = mockPriorityCompetencies.some((p) => p.name === comp);
                return (
                  <SelectItem key={comp} value={comp}>
                    {isPriority ? "" : ""}{comp}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        <label className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg cursor-pointer hover:bg-secondary/50 transition-colors w-full sm:w-auto">
          <input
            type="checkbox"
            checked={showOnlyPriority}
            onChange={(e) => setShowOnlyPriority(e.target.checked)}
            className="w-4 h-4 rounded"
          />
          <span className="text-sm font-medium text-foreground">
            Apenas Prioritárias
          </span>
        </label>

        <Button
          onClick={() => setLocation("/")}
          className="bg-primary text-primary-foreground hover:bg-primary/90 w-full sm:w-auto"
        >
          <Download size={18} className="mr-2" />
          Gerar Resumo
        </Button>
      </div>

      {/* Records List */}
      {showOnlyPriority && (
        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between">
          <p className="text-sm text-amber-900">
            Mostrando apenas registros de competências prioritárias
          </p>
          <button
            onClick={() => setShowOnlyPriority(false)}
            className="text-sm text-amber-700 hover:text-amber-900 font-medium"
          >
            Limpar
          </button>
        </div>
      )}

      <div className="space-y-4">
        {filteredRecords
          .filter((record) => {
            if (showOnlyPriority) {
              return mockPriorityCompetencies.some((p) => p.name === record.competency);
            }
            return true;
          })
          .length === 0 ? (
          <Card className="text-center py-12">
            <p className="text-muted-foreground">Nenhum registro encontrado para este período.</p>
          </Card>
        ) : (
          filteredRecords
            .filter((record) => {
              if (showOnlyPriority) {
                return mockPriorityCompetencies.some((p) => p.name === record.competency);
              }
              return true;
            })
            .map((record) => {
              const isPriority = mockPriorityCompetencies.some((p) => p.name === record.competency);
              return (
                <Card
                  key={record.id}
                  className={`hover:shadow-md ${
                    isPriority ? "border-l-4 border-l-amber-500 bg-amber-50/30" : ""
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            record.type === "positivo"
                              ? "bg-green-100 text-green-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {record.type === "positivo" ? "Positivo" : "Melhoria"}
                        </span>
                        <span className={`text-sm font-medium ${
                          isPriority ? "text-amber-600 font-bold" : "text-accent"
                        }`}>
                          {isPriority && <span className="mr-1">★</span>}
                          {record.competency}
                        </span>
                    <span className="text-xs text-muted-foreground">{record.date}</span>
                  </div>
                  <p className="text-foreground">{record.description}</p>
                </div>

                <div className="flex items-center gap-2 ml-4">
                  {record.visible ? (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Eye size={16} />
                      <span>Visível</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <EyeOff size={16} />
                      <span>Privado</span>
                    </div>
                  )}
                </div>
              </div>
                </Card>
              );
            })
        )}
      </div>

      {/* Summary Stats */}
      {filteredRecords
        .filter((record) => {
          if (showOnlyPriority) {
            return mockPriorityCompetencies.some((p) => p.name === record.competency);
          }
          return true;
        })
        .length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-8">
          <Card className="text-center">
            <p className="text-2xl font-bold text-accent">{filteredRecords.length}</p>
            <p className="text-sm text-muted-foreground mt-1">Registros</p>
          </Card>
          <Card className="text-center">
            <p className="text-2xl font-bold text-accent">
              {filteredRecords.filter((r) => r.type === "positivo").length}
            </p>
            <p className="text-sm text-muted-foreground mt-1">Positivos</p>
          </Card>
          <Card className="text-center">
            <p className="text-2xl font-bold text-accent">
              {filteredRecords.filter((r) => r.type === "melhoria").length}
            </p>
            <p className="text-sm text-muted-foreground mt-1">Melhorias</p>
          </Card>
        </div>
      )}
    </DashboardLayout>
  );
}
