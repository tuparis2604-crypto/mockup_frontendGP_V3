import { useState } from "react";
import { useLocation } from "wouter";
import { ChevronRight, ChevronDown, Users } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import Card from "@/components/Card";

interface TeamMember {
  id: string;
  name: string;
  role: string;
  lastCheckIn: string;
  consistency: "high" | "medium" | "low";
  recordCount: number;
  subordinates?: TeamMember[];
}

const mockTeamMembers: TeamMember[] = [
  {
    id: "1",
    name: "Maria Santos",
    role: "Analista Senior",
    lastCheckIn: "2026-02-08",
    consistency: "high",
    recordCount: 15,
    subordinates: [
      {
        id: "1-1",
        name: "Lucas Ferreira",
        role: "Analista Pleno",
        lastCheckIn: "2026-02-07",
        consistency: "high",
        recordCount: 9,
      },
      {
        id: "1-2",
        name: "Sofia Mendes",
        role: "Analista Junior",
        lastCheckIn: "2026-02-05",
        consistency: "medium",
        recordCount: 5,
      },
    ],
  },
  {
    id: "2",
    name: "Pedro Oliveira",
    role: "Desenvolvedor",
    lastCheckIn: "2026-02-06",
    consistency: "medium",
    recordCount: 8,
  },
  {
    id: "3",
    name: "Ana Costa",
    role: "Designer",
    lastCheckIn: "2026-02-05",
    consistency: "high",
    recordCount: 12,
  },
];

const getConsistencyBadge = (consistency: "high" | "medium" | "low") => {
  switch (consistency) {
    case "high":
      return {
        label: "Consistente",
        color: "bg-green-100 text-green-800",
      };
    case "medium":
      return {
        label: "Moderado",
        color: "bg-amber-100 text-amber-800",
      };
    case "low":
      return {
        label: "Baixo",
        color: "bg-red-100 text-red-800",
      };
  }
};

interface TeamMemberRowProps {
  member: TeamMember;
  level?: number;
  onViewMember: (id: string) => void;
}

function TeamMemberRow({ member, level = 0, onViewMember }: TeamMemberRowProps) {
  const [expanded, setExpanded] = useState(false);
  const badge = getConsistencyBadge(member.consistency);
  const hasSubordinates = member.subordinates && member.subordinates.length > 0;

  return (
    <>
      <Card
        interactive
        onClick={() => onViewMember(member.id)}
        className="hover:shadow-md"
        style={{ marginLeft: `${level * 24}px` }}
      >
        <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 sm:gap-4 flex-1 min-w-0">
            {hasSubordinates && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setExpanded(!expanded);
                }}
                className="text-foreground hover:bg-secondary rounded p-1 transition-colors flex-shrink-0"
              >
                {expanded ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
              </button>
            )}
            {!hasSubordinates && <div className="w-6 flex-shrink-0" />}

            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
              <span className="text-accent-foreground font-bold text-xs sm:text-sm">
                {member.name.charAt(0)}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground text-sm sm:text-base truncate">{member.name}</h3>
              <p className="text-xs sm:text-sm text-muted-foreground truncate">{member.role}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-6 flex-shrink-0">
            <div className="hidden sm:block text-right">
              <div className="flex items-center gap-2 mb-1">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${badge.color}`}>
                  {badge.label}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">Último: {member.lastCheckIn}</p>
            </div>

            <div className="text-right">
              <p className="text-lg font-bold text-accent">{member.recordCount}</p>
              <p className="text-xs text-muted-foreground">registros</p>
            </div>

            <ChevronRight size={20} className="text-muted-foreground hidden sm:block" />
          </div>
        </div>
      </Card>

      {/* Subordinates */}
      {expanded && hasSubordinates && member.subordinates && (
        <div className="space-y-3 mt-3">
          {member.subordinates.map((subordinate) => (
            <TeamMemberRow
              key={subordinate.id}
              member={subordinate}
              level={level + 1}
              onViewMember={onViewMember}
            />
          ))}
        </div>
      )}
    </>
  );
}

export default function MyTeam() {
  const [, setLocation] = useLocation();
  const [userName] = useState("João Silva");
  const [teamMembers] = useState(mockTeamMembers);

  const handleLogout = () => {
    setLocation("/login");
  };

  const handleViewMember = (memberId: string) => {
    setLocation(`/gerido/${memberId}`);
  };

  const totalSubordinates = teamMembers.reduce((sum, m) => {
    return sum + 1 + (m.subordinates?.length || 0);
  }, 0);

  return (
    <DashboardLayout
      userName={userName}
      userRole="Gestor"
      onLogout={handleLogout}
    >
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Meu Time</h1>
        <p className="text-muted-foreground">
          Acompanhe o desenvolvimento e a consistência de registros de seu time.
        </p>
      </div>

      {/* Team Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
        <Card className="text-center">
          <p className="text-3xl font-bold text-accent">{totalSubordinates}</p>
          <p className="text-sm text-muted-foreground mt-2">Pessoas no Time</p>
        </Card>
        <Card className="text-center">
          <p className="text-3xl font-bold text-accent">
            {teamMembers.filter((m) => m.consistency === "high").length}
          </p>
          <p className="text-sm text-muted-foreground mt-2">Registros Consistentes</p>
        </Card>
        <Card className="text-center">
          <p className="text-3xl font-bold text-accent">
            {teamMembers.reduce((sum, m) => sum + m.recordCount, 0)}
          </p>
          <p className="text-sm text-muted-foreground mt-2">Total de Registros</p>
        </Card>
      </div>

      {/* Team Members List with Hierarchy */}
      <div className="space-y-3">
        {teamMembers.map((member) => (
          <TeamMemberRow
            key={member.id}
            member={member}
            onViewMember={handleViewMember}
          />
        ))}
      </div>

      {/* Insights */}
      <Card className="mt-8 bg-blue-50 border-blue-200">
        <div className="flex items-start gap-4">
          <Users size={24} className="text-blue-600 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-bold text-blue-900">Dica de Gestão Hierárquica</h3>
            <p className="text-sm text-blue-800 mt-1">
              Clique na seta ao lado do nome para expandir o time de um colaborador e visualizar
              seus subordinados. Isso permite acompanhar a hierarquia completa da organização.
            </p>
          </div>
        </div>
      </Card>
    </DashboardLayout>
  );
}
